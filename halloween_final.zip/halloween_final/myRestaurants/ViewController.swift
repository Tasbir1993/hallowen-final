//
//  ViewController.swift
//  myRestaurants
//
//  Created by Marcos Bittencourt.
//  Copyright © 2017 Marcos Bittencourt. All rights reserved.
//

import UIKit
import os.log

class ViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, UITextViewDelegate {
    
    //MARK: Properties
    @IBOutlet weak var txtRestName: UITextField!
    @IBOutlet weak var imgRestaurant: UIImageView!
    //@IBOutlet weak var txtAddress: UITextField!
   // @IBOutlet weak var txtComment: UITextField
    let image0 = UIImage(named: "KFC")
    //let image1 = UIImage(named: "images/tick.jpg")
   // let image2 = UIImage(named: "images/cross.jpg")
   // @IBOutlet var myImageView: UIImageView!
    @IBOutlet weak var myimage: UIImageView!
    
    @IBOutlet weak var txtComment: UITextField!
    

    @IBOutlet weak var saveButton: UIBarButtonItem!

    var restaurant :Restaurant?
    
    let image1: UIImage = UIImage(named:"image1")!;
    let image2: UIImage = UIImage(named:"image2")!;
    let image3: UIImage = UIImage(named:"image3")!;
    
  
    
    
    

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set this class as the responsible by the response to user interaction with the text field
        txtRestName.delegate = self
       
        txtComment.delegate = self
        
        // Setting the text view's border
        self.txtComment.layer.borderColor = UIColor(red: 0.9, green: 0.9, blue: 0.9, alpha: 1).cgColor;
        self.txtComment.layer.borderWidth = 1.0;
        self.txtComment.layer.cornerRadius = 8;
        
        // Set up views if editing an existing Meal.
        if let existRestaurant = restaurant {
            //navigationItem.title = existRestaurant.name
            txtRestName.text = existRestaurant.name
            imgRestaurant.image = existRestaurant.image
           //  myimage.image=existRestaurant.smallimage
            txtComment.text = existRestaurant.comment
            if (txtComment.text=="0" || txtComment.text=="1" )
            {
                myimage.image=image3
                
                
            }else if (txtComment.text=="2" || txtComment.text=="3" || txtComment.text=="4")
            {
                myimage.image=image2
                
                
            }
            else
            {
                myimage.image=image1
            }
            
            
            

        }

      
        
       // var imgData : UIImage = crossStatus;
       
            
            
        
       // else if (txtComment >=2 || txtComment <=4) {
      //      imgData = exclamationStatus;
       // }
       // else  {
        //    imgData = ima;
     //   }
        
        updateSaveButtonState()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Actions
    @IBAction func selectImageFromPhotoLibrary(_ sender: UITapGestureRecognizer) {
        print(">>>>>>>>>>> selectImageFromPhotoLibrary")
        // Hide the keyboard.
        txtRestName.resignFirstResponder()
        //txtAddress.resignFirstResponder()
        txtComment.resignFirstResponder()
        
        //Creating the image picker controller
        let imagePickerController = UIImagePickerController()
        
        // Defining the source of the images: the photo library
        imagePickerController.sourceType = .photoLibrary
        
        // Notify the ViewController when the user picks an image.
        imagePickerController.delegate = self
        present(imagePickerController, animated: true, completion: nil)
    }
    
    @IBAction func cancelButton(_ sender: UIBarButtonItem) {
        // Depending on style of presentation (modal or push presentation), this view controller needs to be dismissed in two different ways.
        let isPresentingInAddRestaurantMode = presentingViewController is UINavigationController
        
        if isPresentingInAddRestaurantMode {
            dismiss(animated: true, completion: nil)
        }
        // if it is not a modal presentation, we must test if it is a push presentation
        else if let owningNavigationController = navigationController{
            owningNavigationController.popViewController(animated: true)
        }
        else {
            fatalError("The MealViewController is not inside a navigation controller.")
        }
    }

    

    //MARK: Text Delegate
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // Hide the keyboard.
        textField.resignFirstResponder()

        return true
    }
    
    func textFieldDidEndEditing(_ textField: UITextField) {
        updateSaveButtonState()
       // navigationItem.title = textField.text!
        
        
        if (txtComment.text=="0" || txtComment.text=="1" )
    {
        myimage.image=image3
        
        
        }else if (txtComment.text=="2" || txtComment.text=="3" || txtComment.text=="4")
        {
            myimage.image=image2
            
            
        }
    else{
    myimage.image=image1
    
    
    }
    }
    // Dismiss the text view keyboard, when the user types "Done"
    func textView(_ textView: UITextView, shouldChangeTextIn range: NSRange, replacementText text: String) -> Bool {
        if text == "\n"  // Recognizes enter key in keyboard
        {
            textView.resignFirstResponder()
            return false
        }
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        // Disable the Save button while editing.
        if textField === txtRestName {
            saveButton.isEnabled = false
        }
    }
    
    
    
    // MARK: Image View Delegate
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        // Dismiss the picker if the user canceled.
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        
        // Takes the original image
        if let selectedImage = info[UIImagePickerControllerOriginalImage] as? UIImage {
            
            // Set photoImageView to display the selected image.
            imgRestaurant.image = selectedImage
            
            // Dismiss the picker.
            dismiss(animated: true, completion: nil)
        
        }else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }
        
    }
    
    
    // MARK: Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super.prepare(for: segue, sender: sender)
        
        // Configure the destination view controller only when the save button is pressed.
        if let button = sender as? UIBarButtonItem {
            if (button === saveButton){
                // retrieving the screen data
                let name = txtRestName.text
                let image = imgRestaurant.image
                
                let comment = txtComment.text
                let smallimage = myimage.image
               
                
                //testing if the restaurant's name and ratings are not nil
                if (!(name?.isEmpty)!) {
                    restaurant = Restaurant(name: name!, image: image, comment: comment, smallimage: smallimage!)
                    
                } else {
                    // print the message on debug log
                    os_log("Restaurant do not have a name", log: OSLog.default, type: .debug)
                }
            }
        } else {
            switch segue.identifier! {
                case "goToBreakfast":
                    print(">>>>>>>>>>>>>>>>> Breakfast")
                case "goToLunch":
                    print(">>>>>>>>>>>>>>>>> Lunch")
                case "goToDinner":
                    print(">>>>>>>>>>>>>>>>> Dinner")
            default:
                print("Unknown")
            }
        }
    }
    
    @IBAction func backToRestaurant(unwindSegue: UIStoryboardSegue){
        print(">>>>>>>>>>>>>>>>> I'm back!!!")
    }
    
    
    //MARK: Private Methods 
    private func updateSaveButtonState() {
        // Disable the Save button if the text field is empty.
        if let text = txtRestName.text {
            saveButton.isEnabled = !text.isEmpty
        }
    }
    
}

