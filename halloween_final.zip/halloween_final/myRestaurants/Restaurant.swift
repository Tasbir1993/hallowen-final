//
//  Restaurant.swift
//  myRestaurants
//
//  Created by Marcos Alexandre
//  Copyright © 2017 Marcos Bittencourt. All rights reserved.
//

import UIKit

class Restaurant {
    
    //MARK: Properties
    public private(set) var name :String
    public private(set) var image :UIImage!
   // public private(set) var address :String!
    public private(set) var comment :String!
     public private(set) var smallimage :UIImage!
    
    init(name: String, image: UIImage!, comment :String!,smallimage:UIImage){
        self.name = name
        self.image = image
      self.smallimage = smallimage
        self.comment = comment
       
    }
    
    public func setName(name :String!){
        if (name.isEmpty){
            self.name = " "
        } else {
            self.name = name
        }
    }
    
    public func setImage(image :UIImage!){
        self.image = image
    }
    
    public func setImage1(smallimage :UIImage!){
      self.smallimage = smallimage
    }
  
    public func setComment(comment: String!){
        self.comment = comment
    }
    
    
   
    
}
